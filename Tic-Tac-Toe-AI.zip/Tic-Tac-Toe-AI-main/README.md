# Tic-Tac-Toe AI 🎮🤖

A Python-based Tic-Tac-Toe game with Minimax AI for a smart opponent.

## Features
- 🎲 Play against AI
- 🧠 AI uses Minimax algorithm

## How to Play
1. Run `python tic_tac_toe.py`
2. Play against AI

## License
MIT License
